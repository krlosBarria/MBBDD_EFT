-- Poblar ACADEMIA
INSERT INTO academia (rut, nombre, tipo_organizacion, fecha_vencimiento_directorio, direccion, unidad_vecinal, telefono, email, numero_cta_bancaria, tipo_cta_bancaria, banco) VALUES (12345678, 'Academia de Ciencias', 'Privada', TO_DATE('2025-12-31', 'YYYY-MM-DD'), 'Av. Libertador 123', 'Unidad 1', 987654321, 'contacto@ciencias.cl', 1234567890, 'Corriente', 'Banco Estado');
INSERT INTO academia (rut, nombre, tipo_organizacion, fecha_vencimiento_directorio, direccion, unidad_vecinal, telefono, email, numero_cta_bancaria, tipo_cta_bancaria, banco) VALUES (87654321, 'Academia de Artes', 'P�blica', TO_DATE('2024-11-30', 'YYYY-MM-DD'), 'Calle Cultura 456', 'Unidad 2', 123456789, 'info@artes.cl', 9876543210, 'Ahorro', 'Banco Chile');

-- Poblando CURSO
INSERT INTO curso (id_curso, nombre, turno, academia_rut) VALUES (1, 'Matem�ticas Avanzadas', 'Ma�ana', 12345678);
INSERT INTO curso (id_curso, nombre, turno, academia_rut) VALUES (2, 'Historia del Arte', 'Tarde', 87654321);

-- Poblar TURNO
INSERT INTO turno (id_turno, horario) VALUES (1, '08:00 - 10:00');
INSERT INTO turno (id_turno, horario) VALUES (2, '10:00 - 12:00');

-- Poblar CURSO_TURNO
INSERT INTO curso_turno (curso_id_curso, turno_id_turno) VALUES (1, 1);
INSERT INTO curso_turno (curso_id_curso, turno_id_turno) VALUES (1, 2);

-- Poblar POSTULACION
INSERT INTO postulacion (id_postulacion, fecha_postulacion, monto_solicitado, estado, academia_rut) VALUES (1, TO_DATE('2024-01-15', 'YYYY-MM-DD'), 500000, 'Pendiente', 12345678);
INSERT INTO postulacion (id_postulacion, fecha_postulacion, monto_solicitado, estado, academia_rut) VALUES (2, TO_DATE('2024-02-20', 'YYYY-MM-DD'), 300000, 'Aprobado', 87654321);

-- Poblar PROFESOR
INSERT INTO profesor (id_profesor, nombre, tipo_contrato, email, telefono, profesor_id) VALUES (1, 'Juan P�rez', 'Tiempo Completo', 'juan.perez@academia.cl', 987654321, 1);
INSERT INTO profesor (id_profesor, nombre, tipo_contrato, email, telefono, profesor_id) VALUES (2, 'Mar�a L�pez', 'Medio Tiempo', 'maria.lopez@academia.cl', 123456789, 2);

-- Poblar PROFESOR_TURNO
INSERT INTO profesor_turno (profesor_profesor_id, turno_id_turno) VALUES (1, 1);
INSERT INTO profesor_turno (profesor_profesor_id, turno_id_turno) VALUES (2, 2);
